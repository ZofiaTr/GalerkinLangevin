function val=KroneckerDelta(j,k)

if(j==k)
    
    val=1;
    
else
    
    val=0;
    
end


end 