function val=integrateInRestrainedDynamics(f,eps)

val=integral(f, -eps,eps);

end